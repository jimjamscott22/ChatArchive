# Handoff: ChatArchive Timeline view (option 2c, Modernist)

## Overview
A new **Timeline** screen for ChatArchive, plus a visual restyle to the Modernist design system. The Timeline shows the archive as a timetable: a stat row of archive totals, a filter/date-range bar, and one column per month with that month's conversations stacked newest-first. Clicking a conversation opens it in the existing conversation reader.

It sits alongside the existing Library (search + list + reader), Projects and Analytics screens as a top-level nav item. It does not replace the Library.

## About the Design Files
The files in this bundle are **design references created in HTML**: prototypes that show the intended look and behaviour, not production code. Recreate the design in the existing ChatArchive frontend (React + TypeScript, `frontend/src/App.tsx` and `frontend/src/components/`), using its existing patterns, data fetching and Lucide icons (`lucide-react`, already used in the app). Do not ship the HTML.

Open `ChatArchive Layouts Modernist.dc.html` in a browser; the relevant mockup is the one labelled **2c**. Options 2a and 2b in the same file are not part of this handoff.

## Fidelity
**High-fidelity** for layout, type, colour, rules and spacing. Conversation titles, per-month counts and the stat values in the mock are **sample data** (only the 1,123 / 1,056 / 67 totals are real); wire every value to real data.

## Global restyle: Modernist
Apply these rules across the app, not just the new screen:
- Font: **Archivo** everywhere (Google Fonts, weights 400 / 600 / 800). Headings 800, labels 600, body 400.
- **Zero border radius** on everything: buttons, inputs, tags, cards, dialogs.
- Structure comes from rules: **2px** rules (`--color-divider`) between major regions, **1px** rules between rows and cells.
- Light ground (`#f3f2f2`), ink text (`#201e1d`). Red accent (`#ec3013`) only for the primary action, the active nav item, the active filter, highlighted figures and **one** solid red field per screen (the current month header).
- Button labels are flush left, never centred (`justify-content:flex-start` on buttons wider than their label).
- No decorative shadows. Lucide icons, stroke 2, `stroke-linecap: square`.
- Focus: `outline: 2px solid #ec3013; outline-offset: 2px` on `:focus-visible`. No browser-default blue ring.

The full token sheet and component classes are in `_ds/modernist-…/styles.css` in this bundle. Port the CSS variables into the app's global stylesheet (or theme file) and reuse them.

## Screen: Timeline

Frame in the mock is 1280×820. The screen fills the viewport (`height: 100vh`, flex column). Only the month grid scrolls.

### 1. Top nav (`.nav`)
- Flex row, `align-items:center`, `gap:16px`, padding `14px 28px`, `border-bottom: 2px solid var(--color-divider)`.
- Brand "ChatArchive": Archivo 800, 20px, `margin-right:24px`.
- Links: Library · **Timeline** · Projects · Analytics. 14px, ink colour. Hover and current page (`aria-current="page"`) in `--color-accent`.
- Spacer `flex:1`, then the search input (`.input`, width 260px, placeholder "Search"). Submitting a search filters the timeline (see Interactions).
- Keep the existing Import / settings actions reachable. Put them in this nav to the right of search as `.btn-icon` buttons (`Upload`, `Settings` Lucide icons).

### 2. Stat row
- CSS grid, `grid-template-columns: repeat(5, minmax(0,1fr))`, `border-bottom: 2px solid var(--color-divider)`.
- Each cell: padding `16px 28px 18px`, `border-right: 1px solid var(--color-divider)`, flex column, gap 2px.
  - Label: 11px, `letter-spacing:.08em`, uppercase, `--color-neutral-700` (#605d5d).
  - Value: Archivo 800, 36px, line-height 1, `letter-spacing:-.02em`, `font-variant-numeric: tabular-nums`, ink colour.
- Cells, in order: **Conversations** (total), **Tagged {tag}** (count for the active tag filter; value in `--color-accent`; hide or show "Filtered" when no tag is active), **ChatGPT**, **Claude**, **This month**.
- Values come from the existing stats endpoint the dashboard/analytics already use. Format with thousands separators (`1,123`).

### 3. Filter / range bar
- Flex row, `justify-content:space-between`, `align-items:center`, padding `14px 28px`.
- Left: active filter chips, `gap:8px`. Each is `.tag.tag-outline` (1px accent border, accent text, 11px, padding `3px 10px`, radius 0) with a trailing "×" that removes the filter. Example: `coding ×`, `Claude + ChatGPT`.
- Right: range pager, `gap:6px`: `.btn.btn-secondary.btn-icon` (36×36) "←", label (600, 14px, `min-width:150px`) such as "May – Aug 2026", `.btn-icon` "→". Use Lucide `ArrowLeft` / `ArrowRight` in production.

### 4. Month grid
- Container: `flex:1`, `min-height:0`, CSS grid `repeat(4, minmax(0,1fr))`, `border-top: 2px solid var(--color-divider)`, margin `0 28px`.
- Shows **4 consecutive months**; the newest month is the rightmost column. The pager moves the window by one month.
- **Column**: `border-right: 1px solid var(--color-divider)`, flex column. The column body scrolls on its own (`overflow-y:auto`).
- **Column header**: flex, `space-between`, `align-items:baseline`, padding `12px 16px`, `border-bottom: 2px solid var(--color-divider)`.
  - Month name: Archivo 800, 22px ("May", "June"…). Add the year when the window spans two years.
  - Count: 13px, tabular nums. Number of conversations that month after filters.
  - **Current calendar month**: background `--color-accent` (#ec3013), text `--color-bg` (#f3f2f2). Other months are transparent with ink text. Only one red header at a time.
- **Row** (one conversation): grid `28px minmax(0,1fr)`, `gap:8px`, padding `10px 16px`, `border-bottom: 1px solid var(--color-divider)`, `cursor:pointer`. Hover background `--color-surface` (#eae9e9).
  - Day: 12px, 600, tabular nums, `--color-neutral-700`, zero-padded ("04").
  - Title: 14px, 600, line-height 1.25. Wraps; no truncation.
  - Meta line: 11px, `letter-spacing:.06em`, uppercase, "{SOURCE} · {n} MSGS". Colour `--color-accent-700` (#ae1800) for Claude, `--color-neutral-700` for ChatGPT.
- Rows are ordered newest first within a column. Dates use `updated_at` by default; follow the Library's sort setting if it's set to created.

## Interactions & Behavior
- **Row click**: open the conversation in the existing reader view (same route/state the Library uses when a conversation is selected). Back returns to the Timeline with the same range and filters.
- **Pager ← / →**: shift the 4-month window by one month. Disable → when the newest month is the current month, and ← when the oldest month in the archive is visible.
- **Search** (nav input): filters rows in every column. Column counts and the "Tagged" stat update to match. Debounce about 250ms, using the same search API as the Library.
- **Filter chips**: removing a chip clears that filter. Tag/source filters set in the Library carry over to the Timeline, and the other way round (shared filter state).
- **Empty month**: header shows count `0`. Body shows one muted line, "No conversations" (13px, `--color-neutral-700`, padding `10px 16px`).
- **Loading**: keep the header row. Show 5 placeholder rows per column (row height ≈ 52px, `--color-neutral-200` bars, no shimmer needed).
- **Error**: a single row spanning the grid with the error text and a `.btn-secondary` "Retry".
- **Keyboard**: rows are focusable (`button` or `tabindex=0`) and open with Enter. Arrow keys between rows are optional.
- **Responsive**: under 1100px show 3 months, under 800px 2, under 560px 1 (the pager still steps by one month). The stat row wraps to `repeat(auto-fit, minmax(160px,1fr))`.

## State Management
- `rangeEnd: YearMonth` (default: current month); `monthsVisible: 1–4` (from viewport width).
- Shared with the Library: `searchQuery`, `sourceFilter: 'all' | 'chatgpt' | 'claude'`, `tagFilter: string[]`, `projectFilter`.
- Data: conversations grouped by month for the visible window. Either fetch the list with a date range (`from`/`to`) plus the existing filters and group on the client, or add a backend endpoint that returns `{ month, count, items[] }` per month. Items need `id, title, source, updated_at (or created_at), message_count`.
- Stats: totals per source, total for the active tag, count for the current month.

## Design Tokens (Modernist)
Colours
- `--color-bg` #f3f2f2 · `--color-surface` #eae9e9 · `--color-text` #201e1d
- `--color-accent` #ec3013 · hover `--color-accent-600` #dd2b0f · pressed / text-on-light `--color-accent-700` #ae1800
- `--color-divider` = #201e1d at 40% (`color-mix(in srgb, #201e1d 40%, transparent)`)
- Neutrals: 200 #eae7e7 · 300 #d7d3d3 · 600 #7d7979 · 700 #605d5d · 800 #444141
- Accent tints: 100 #fff2ef · 200 #ffe0d9

Type (Archivo)
- h1 42 / h2 32 / h3 25 / h4 20 · body 15 / line-height 1.55 · headings line-height 1.12, `letter-spacing:-0.015em`, weight 800
- Labels 11px uppercase `.08em` · stat figures 36/800 · month headers 22/800 · row titles 14/600

Spacing: 4 · 8 · 12 · 16 · 24 · 32 (`--space-1` … `--space-8`). Screen gutters are 28px.

Radius: 0 everywhere.

Shadows: `--shadow-sm/md/lg` exist for dialogs only. None on this screen.

Components used: `.nav`, `.nav-brand`, `.input`, `.btn`, `.btn-secondary`, `.btn-icon`, `.btn-primary` (Import), `.tag-outline`. See `styles.css`.

## Assets
None. Icons are Lucide (`Search`, `ArrowLeft`, `ArrowRight`, `Upload`, `Settings`, `X`). The font is Archivo from Google Fonts.

## Files
- `screenshots/2c-timeline.png`: the Timeline screen at 2× (2560×1640, from a 1280×820 frame).
- `ChatArchive Layouts Modernist.dc.html`: the mockups. Build **2c** only. It opens directly in a browser (needs `support.js` alongside).
- `_ds/modernist-…/styles.css`: Modernist tokens and component classes, the source of truth for values.
- `support.js`, `_ds/…/_ds_bundle.js`: runtime needed to open the mock. Not for production.
